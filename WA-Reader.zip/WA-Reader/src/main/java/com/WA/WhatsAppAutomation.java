


                package com.WA;

        import org.openqa.selenium.By;
        import org.openqa.selenium.WebDriver;
        import org.openqa.selenium.chrome.ChromeDriver;
        import org.openqa.selenium.chrome.ChromeOptions;
        import org.openqa.selenium.support.ui.ExpectedConditions;
        import org.openqa.selenium.support.ui.WebDriverWait;

        import java.time.Duration;
        import java.util.Scanner;

        public class WhatsAppAutomation {
            public static void main(String[] args) {
                // Set path for ChromeDriver
                System.setProperty("webdriver.chrome.driver", "C:\\IV team\\Codes & Projects\\ai-dt-iv-framework\\iv-script-generator\\src\\main\\resources\\com\\airindia\\drivers\\chromedriver.exe");
                // Set Chrome options
                ChromeOptions options = new ChromeOptions();
                // No user data directory specified
                WebDriver driver = new ChromeDriver(options);

                Scanner scanner = new Scanner(System.in);

                try {
                    // Open WhatsApp Web
                    driver.get("https://youtube.com/");
                    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));

                    // Wait for user to scan QR code (do this manually)
                    System.out.println("Please scan the QR code and press Enter...");
                    System.in.read();

                    // Ask for the contact name
                    System.out.print("Enter the name of the contact: ");
                    String contactName = scanner.nextLine();

                    // Wait until the chat list is visible
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@role='grid']")));

                    // Navigate to specific chat using user input
                    driver.findElement(By.xpath("//span[@title='" + contactName + "']")).click();

                    // Wait for messages to load
                    wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.message-in")));

                    // Read the last message (this may need adjustment based on your WhatsApp layout)
                    String lastMessage = driver.findElements(By.cssSelector("div.message-in span.selectable-text"))
                            .get(driver.findElements(By.cssSelector("div.message-in span.selectable-text")).size() - 1)
                            .getText();

                    System.out.println("Last message from " + contactName + ": " + lastMessage);
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    // Close the scanner and browser
                    scanner.close();
                    driver.quit();
                }
            }
        }
